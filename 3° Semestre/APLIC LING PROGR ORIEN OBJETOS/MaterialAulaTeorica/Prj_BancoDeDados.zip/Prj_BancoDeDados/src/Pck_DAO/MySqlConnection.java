package Pck_DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MySqlConnection 
{
	private static String status = "N�o conectou...";
	private static String serverName = "127.0.0.1";
	private static String mydatabase ="lpbd";
    private static String url = "jdbc:mysql://" + serverName + "/" + mydatabase;
    private static String username = "aluno";
    private static String password = "4@11";
    
	public MySqlConnection() {}

	public java.sql.Connection getMySqlConnection() 
	{
	        Connection connection = null;
	        try 
	        {
	        	String driverName = "com.mysql.jdbc.Driver";
	        	Class.forName(driverName);
	        	connection = DriverManager.getConnection(url, username, password);
	        	if (connection != null) 
	        	{
		        	status = ("STATUS--->Conectado com sucesso!");
	        		System.out.println(status);
	        	}
	        	else 
	        	{
	        		status = ("STATUS--->N�o foi possivel realizar conex�o");
	        		System.out.println(status);
	        	}
        		return connection;
        	} 
	        catch (ClassNotFoundException e) 
	        {
	        	System.out.println("O driver expecificado nao foi encontrado.");
	            return null;
	        } 
	        catch (SQLException e) 
	        {
	        	System.out.println("Nao foi possivel conectar ao Banco de Dados.");
	        	return null;
	        }
	    }
	    public String statusConection() 
	    {
	    	return status;
	    }
	    public boolean CloseConnection() 
	    {
	    	try 
	    	{
	    		this.getMySqlConnection().close();
	            return true;
	        } 
	    	catch (SQLException e) 
	    	{
	    		return false;
	        }
	    }
	    public java.sql.Connection RestartConnection() 
	    {
	    	this.CloseConnection();
	        return this.getMySqlConnection();
	    }
}


