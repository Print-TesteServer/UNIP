package Pck_Model;

public class TesteModel 
{
	private int pkId;
	private String dsTeste;
	
	public TesteModel()
	{
		
	}
	
	public int getPkId() {
		return pkId;
	}

	public void setPkId(int pkId) {
		this.pkId = pkId;
	}

	public String getDsTeste() {
		return dsTeste;
	}

	public void setDsTeste(String dsTeste) {
		this.dsTeste = dsTeste;
	}
}

