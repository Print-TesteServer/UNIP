package Pck_View;

public class Main 
{
	public static void main(String [] args)
	{
		MyWindow myWindow = new MyWindow();
		myWindow.setVisible(true);
	}
}
