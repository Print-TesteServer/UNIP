package Pck_Controller;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Pck_Model.TesteModel;

import Pck_DAO.MySqlConnection;

public class TesteController 
{
	private MySqlConnection mySqlConnection;
	private PreparedStatement preparedStatement;
	private TesteModel testeModel;
	private ResultSet resultSet;
	private String insertQuery = "INSERT INTO teste (ds_teste) VALUES(?);";
	private String updateQuery = "UPDATE teste SET ds_teste = ? WHERE pk_id = ?;";
	private String deleteQuery = "DELETE FROM teste WHERE pk_id = ?;";
	private String readQuery = "SELECT * FROM teste;";
	
	public TesteController ()
	{
		this.mySqlConnection = new MySqlConnection();
		this.testeModel = new TesteModel();
	}
	
	public void InsertTeste(String dsTeste)
	{
		this.testeModel.setDsTeste(dsTeste);
		
		try 
		{
			this.preparedStatement = this.mySqlConnection.getMySqlConnection().prepareStatement(insertQuery);
			this.preparedStatement.setString (1, testeModel.getDsTeste());
			this.preparedStatement.execute();
			
			this.mySqlConnection.CloseConnection();
		} 
		catch (SQLException e) 
		{
			System.out.println("Query error: " + e.toString());
		}
	}
	
	public void UpdateTeste(int pkId, String dsTeste)
	{
		this.testeModel.setPkId(pkId);
		this.testeModel.setDsTeste(dsTeste);
		try 
		{
			this.preparedStatement = this.mySqlConnection.getMySqlConnection().prepareStatement(updateQuery);
			this.preparedStatement.setString (1, testeModel.getDsTeste());
			this.preparedStatement.setInt(2, testeModel.getPkId());
			this.preparedStatement.execute();
			
			this.mySqlConnection.CloseConnection();
		} 
		catch (SQLException e) 
		{
			System.out.println("Query error: " + e.toString());
		}
	}
	
	public void DeleteTeste(int pkId)
	{
		this.testeModel.setPkId(pkId);
		try 
		{
			this.preparedStatement = this.mySqlConnection.getMySqlConnection().prepareStatement(deleteQuery);
			this.preparedStatement.setInt(1, testeModel.getPkId());
			this.preparedStatement.execute();
			
			this.mySqlConnection.CloseConnection();
		} 
		catch (SQLException e) 
		{
			System.out.println("Query error: " + e.toString());
		}
	}
	
	public String ReadTeste()
	{
		String result = "";
		try 
		{
			this.resultSet = this.mySqlConnection.getMySqlConnection().createStatement().executeQuery(readQuery);
			
			result += "id\tteste\n";
			
			while (this.resultSet.next())
			{
				result += this.resultSet.getInt("pk_id") + "\t" + this.resultSet.getString("ds_teste") + "\n";
			}
			
			this.mySqlConnection.CloseConnection();
			
			return result;
		} 
		catch (SQLException e) 
		{
			System.out.println("Query error: " + e.toString());
			
			return result;
		}
	}
}
