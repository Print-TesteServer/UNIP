package Pck_Model;

public class TesteModel 
{
	private int pkId;
	private String dsTeste;
	
	public TesteModel()
	{
		
	}
	public TesteModel(int id, String teste)
	{
		this.pkId = id;
		this.dsTeste = teste;
	}
	
	public TesteModel(String teste)
	{
		this.dsTeste = teste;
	}
	
	public TesteModel(int id)
	{
		this.pkId = id;
	}
	
	
	public int getPkId() {
		return pkId;
	}
	public void setPkId(int pkId) {
		this.pkId = pkId;
	}
	public String getDsTeste() {
		return dsTeste;
	}
	public void setDsTeste(String dsTeste) {
		this.dsTeste = dsTeste;
	}
}

