package Pck_DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class HibernateSession 
{
	private Configuration configuration;
	private ServiceRegistryBuilder registry;
	private ServiceRegistry serviceRegistry;
	private SessionFactory sessionFactory;
	private Session session;
	
	public HibernateSession()
	{
		this.configuration = new Configuration().configure();
		this.registry = new ServiceRegistryBuilder();
		this.registry.applySettings(this.configuration.getProperties());
		this.serviceRegistry = this.registry.buildServiceRegistry();
		this.sessionFactory = this.configuration.buildSessionFactory(this.serviceRegistry);
		this.session = sessionFactory.openSession();
	}
	
	public Session GetSession()
	{
		return this.session;
	}
}


