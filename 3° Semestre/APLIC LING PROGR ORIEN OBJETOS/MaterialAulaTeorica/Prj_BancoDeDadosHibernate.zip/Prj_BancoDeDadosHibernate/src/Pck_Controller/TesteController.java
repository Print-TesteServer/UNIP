package Pck_Controller;

import java.util.ArrayList;
import org.hibernate.Session;

import Pck_Model.TesteModel;

import Pck_DAO.HibernateSession;

public class TesteController 
{
	private HibernateSession hibernateSession;
	private Session hSession;
	
	public TesteController ()
	{
		this.hibernateSession = new HibernateSession();
		this.hSession = this.hibernateSession.GetSession();
	}
	
	public void InsertTeste(String dsTeste)
	{
		TesteModel teste = new TesteModel(dsTeste);
		
		this.hSession.beginTransaction();
		
		try
		{
			this.hSession.persist(teste);
		}
		catch(Exception error)
		{
			this.hSession.getTransaction().rollback();
		}
		
		this.hSession.getTransaction().commit();
	}
	
	public void UpdateTeste(int pkId, String dsTeste)
	{
		this.hSession.beginTransaction();
		
		try
		{
			TesteModel teste = (TesteModel) this.hSession.load(TesteModel.class, new Integer(pkId));
			teste.setDsTeste(dsTeste);
			
			this.hSession.update(teste);
		}
		catch(Exception error)
		{
			this.hSession.getTransaction().rollback();
		}
		
		this.hSession.getTransaction().commit();
	}
	
	public void DeleteTeste(int pkId)
	{
		this.hSession.beginTransaction();
		
		try
		{
			TesteModel teste = (TesteModel) this.hSession.load(TesteModel.class, new Integer(pkId));
			this.hSession.delete(teste);
		}
		catch(Exception error)
		{
			this.hSession.getTransaction().rollback();
		}
		
		this.hSession.getTransaction().commit();
	}
	
	public String ReadTeste()
	{
		String result = "id\tteste\n";
		
		ArrayList<TesteModel> teste;
		
		this.hSession.beginTransaction();
		
		try
		{
			teste = (ArrayList<TesteModel>) this.hSession.createCriteria(TesteModel.class).list();
			
			for (int i = 0; i < teste.size(); i ++)
			{
				result += teste.get(i).getPkId()  + "\t" + teste.get(i).getDsTeste() + "\n";
			}
		}
		catch(Exception error)
		{
			this.hSession.getTransaction().rollback();
		}
		
		this.hSession.getTransaction().commit();
		
		return result;
	}
}
