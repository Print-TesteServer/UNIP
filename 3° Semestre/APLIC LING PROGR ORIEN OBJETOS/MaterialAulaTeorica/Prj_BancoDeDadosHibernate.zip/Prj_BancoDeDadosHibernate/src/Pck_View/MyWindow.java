package Pck_View;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import Pck_Model.TesteModel;
import Pck_Controller.TesteController;

public class MyWindow extends JFrame
{
	private JLabel jl_teste, jl_id;
	private JTextField jtf_teste, jtf_id;
	private JTextArea jta_read;
	private JButton jb_insert, jb_update, jb_remove, jb_read;
	
	private TesteController testeController;
	
	public MyWindow()
	{
		this.testeController = new TesteController();
		
		this.CreateGUI();
		this.CreateEvents();
	}
	
	public void CreateGUI()
	{
		this.setSize(new Dimension(600, 600));
		this.setTitle("Meu primeiro projeto Java/SQL");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setLayout(new FlowLayout());
		
		this.jl_id = new JLabel("id");
		this.jl_id.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jl_id);
		
		this.jtf_id = new JTextField();
		this.jtf_id.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jtf_id);
		
		this.jl_teste = new JLabel("teste");
		this.jl_teste.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jl_teste);
		
		this.jtf_teste = new JTextField();
		this.jtf_teste.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jtf_teste);
		
		this.jb_insert = new JButton("Inserir");
		this.jb_insert.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jb_insert);
		
		this.jb_update = new JButton("Alterar");
		this.jb_update.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jb_update);
		
		this.jb_remove = new JButton("Excluir");
		this.jb_remove.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jb_remove);

		this.jb_read = new JButton("Ler");
		this.jb_read.setPreferredSize(new Dimension(120,30));
		this.getContentPane().add(jb_read);
		
		this.jta_read = new JTextArea();
		this.jta_read.setPreferredSize(new Dimension(120,240));
		this.getContentPane().add(jta_read);
	}
	
	public void CreateEvents()
	{
		this.jb_insert.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				testeController.InsertTeste(jtf_teste.getText());
			}
		});
		
		this.jb_update.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				testeController.UpdateTeste(Integer.parseInt(jtf_id.getText()),
											jtf_teste.getText());
			}
		});
		
		this.jb_remove.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				testeController.DeleteTeste(Integer.parseInt(jtf_id.getText()));
			}
		});
		
		this.jb_read.addActionListener(new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				jta_read.setText(testeController.ReadTeste());
			}
		});
	}
}
